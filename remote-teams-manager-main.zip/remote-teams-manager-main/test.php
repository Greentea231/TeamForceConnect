<?php
include 'functions.php';

endTimer();